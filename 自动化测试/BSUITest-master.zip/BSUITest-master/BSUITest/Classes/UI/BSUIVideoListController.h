//
//  BSUIVideoListController.h
//  Pods
//
//  Created by Vic on 2018/5/28.
//

#import <UIKit/UIKit.h>


/**
 录制与回放视频列表控制器
 */
@interface BSUIVideoListController : UIViewController

@property (nonatomic, strong) NSString *recName;
@property (nonatomic, strong) NSString *recTimestamp;

@end
