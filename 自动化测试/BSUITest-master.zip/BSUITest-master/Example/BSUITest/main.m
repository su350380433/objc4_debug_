//
//  main.m
//  BSUITest
//
//  Created by vviicc on 05/26/2018.
//  Copyright (c) 2018 vviicc. All rights reserved.
//

@import UIKit;
#import "BSAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BSAppDelegate class]));
    }
}
