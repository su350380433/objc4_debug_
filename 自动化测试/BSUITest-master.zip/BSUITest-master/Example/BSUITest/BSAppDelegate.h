//
//  BSAppDelegate.h
//  BSUITest
//
//  Created by vviicc on 05/26/2018.
//  Copyright (c) 2018 vviicc. All rights reserved.
//

@import UIKit;

@interface BSAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
