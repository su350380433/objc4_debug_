//
//  BSUITestWindow.h
//  Pods
//
//  Created by Vic on 2018/5/28.
//

#import <UIKit/UIKit.h>

@interface BSUITestWindow : UIWindow

@property (nonatomic, assign) CGPoint viewCenter;

@end
