//
//  BSUIVideoPlayerController.h
//  Pods
//
//  Created by Vic on 2018/5/28.
//

#import <UIKit/UIKit.h>

/**
 单个视频播放控制器
 */
@interface BSUIVideoPlayerController : UIViewController

@property (nonatomic, strong) NSURL *videoURL;

@end
