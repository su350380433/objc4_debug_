//
//  BSUIRecordListController.h
//  Pods
//
//  Created by Vic on 2018/5/28.
//

#import <UIKit/UIKit.h>


/**
 最近录制控制器
 */
@interface BSUIRecordListController : UIViewController

@end
